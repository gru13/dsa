#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 10

int size = 0;

void swap(int *a, int *b) {
  int temp = *b;
  *b = *a;
  *a = temp;
}

void heapify(int array[], int size, int i) {
  if (size == 1) {
    printf("Single element in the heap");
  } else {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;
    if (l < size && array[l] > array[largest])
      largest = l;
    if (r < size && array[r] > array[largest])
      largest = r;

    if (largest != i) {
      swap(&array[i], &array[largest]);
      heapify(array, size, largest);
    }
  }
}

void insert(int array[], int newNum) {
  if (size == MAX_SIZE) {
    printf("Priority queue is full. Cannot enqueue.\n");
    return;
  }

  if (size == 0) {
    array[0] = newNum;
    size += 1;
  } else {
    array[size] = newNum;
    size += 1;
    for (int i = size / 2 - 1; i >= 0; i--) {
      heapify(array, size, i);
    }
  }
}

void deleteRoot(int array[], int num) {
  int i;
  for (i = 0; i < size; i++) {
    if (num == array[i])
      break;
  }

  swap(&array[i], &array[size - 1]);
  size -= 1;
  for (int i = size / 2 - 1; i >= 0; i--) {
    heapify(array, size, i);
  }
}

void printArray(int array[], int size) {
  for (int i = 0; i < size; ++i)
    printf("%d ", array[i]);
  printf("\n");
}

void menu(int array[]) {
  int choice, num;
  while (1) {
    printf("\nPriority Queue Menu:\n");
    printf("1. Enqueue\n");
    printf("2. Dequeue\n");
    printf("3. Display\n");
    printf("4. Exit\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
      case 1:
        printf("Enter the element to enqueue: ");
        scanf("%d", &num);
        insert(array, num);
        break;
      case 2:
        if (size > 0) {
          printf("Dequeued element: %d\n", array[0]);
          deleteRoot(array, array[0]);
        } else {
          printf("Priority queue is empty.\n");
        }
        break;
      case 3:
        if (size > 0) {
          printf("Priority Queue: ");
          printArray(array, size);
        } else {
          printf("Priority queue is empty.\n");
        }
        break;
      case 4:
        printf("Exiting...\n");
        return;
      default:
        printf("Invalid choice. Please try again.\n");
        break;
    }
  }
}

int main() {
  int array[MAX_SIZE];

  menu(array);

  return 0;
}
