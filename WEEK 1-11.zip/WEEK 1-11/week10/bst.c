#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

typedef struct Node* NODE;

struct Node {
    NODE lft;
    NODE ryt;
    int data;
};

NODE create_node(int val) {
    NODE n = (NODE)malloc(sizeof(struct Node));
    n->data = val;
    n->lft = NULL;
    n->ryt = NULL;
    return n;
}

void insert(NODE tree, int val) {
    if (val == tree->data) {
        printf("Value already exists in the BST.\n");
        return;
    }
    if (val < tree->data) {
        if (tree->lft == NULL) {
            tree->lft = create_node(val);
            printf("Value %d inserted successfully.\n", val);
            return;
        } else {
            return insert(tree->lft, val);
        }
    }
    if (val > tree->data) {
        if (tree->ryt == NULL) {
            tree->ryt = create_node(val);
            printf("Value %d inserted successfully.\n", val);
            return;
        } else {
            return insert(tree->ryt, val);
        }
    }
}

NODE find_min(NODE node) {
    if (node == NULL) {
        return NULL;
    } else if (node->lft == NULL) {
        return node;
    } else {
        return find_min(node->lft);
    }
}

NODE delete_node(NODE node, int val) {
    if (node == NULL) {
        printf("Value not found in the BST.\n");
        return node;
    }
    if (val < node->data) {
        node->lft = delete_node(node->lft, val);
    } else if (val > node->data) {
        node->ryt = delete_node(node->ryt, val);
    } else {
        if (node->lft == NULL && node->ryt == NULL) {
            free(node);
            node = NULL;
            printf("Value %d deleted successfully.\n", val);
        } else if (node->lft == NULL) {
            NODE temp = node;
            node = node->ryt;
            free(temp);
            printf("Value %d deleted successfully.\n", val);
        } else if (node->ryt == NULL) {
            NODE temp = node;
            node = node->lft;
            free(temp);
            printf("Value %d deleted successfully.\n", val);
        } else {
            NODE temp = find_min(node->ryt);
            node->data = temp->data;
            node->ryt = delete_node(node->ryt, temp->data);
            printf("Value %d deleted successfully.\n", val);
        }
    }
    return node;
}

NODE create_tree(int* arr, int len) {
    if (len <= 0) {
        return NULL;
    }
    NODE Root = create_node(arr[0]);
    for (int i = 1; i < len; i++) {
        insert(Root, arr[i]);
    }
    return Root;
}

void inorder(NODE node) {
    if (node == NULL)
        return;

    inorder(node->lft);
    printf("%d ", node->data);
    inorder(node->ryt);
}

void preorder(NODE node) {
    if (node == NULL)
        return;

    printf("%d ", node->data);
    preorder(node->lft);
    preorder(node->ryt);
}

void postorder(NODE node) {
    if (node == NULL)
        return;

    postorder(node->lft);
    postorder(node->ryt);
    printf("%d ", node->data);
}

int main() {
    int arr[] = {8, 1, 2, 9, 10, 11, 22, 5, 19, 55};
    int len = sizeof(arr) / sizeof(arr[0]);
    NODE Root = create_tree(arr, len);

    int choice = 0;
    int value;
    while (choice != 5) {
        printf("Binary Search Tree Operations:\n");
        printf("1. Inorder Traversal\n");
        printf("2. Preorder Traversal\n");
        printf("3. Postorder Traversal\n");
        printf("4. Insert a value\n");
        printf("5. Delete a value\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Inorder Traversal: ");
                inorder(Root);
                printf("\n");
                break;
            case 2:
                printf("Preorder Traversal: ");
                preorder(Root);
                printf("\n");
                break;
            case 3:
                printf("Postorder Traversal: ");
                postorder(Root);
                printf("\n");
                break;
            case 4:
                printf("Enter the value to insert: ");
                scanf("%d", &value);
                insert(Root, value);
                break;
            case 5:
                printf("Enter the value to delete: ");
                scanf("%d", &value);
                Root = delete_node(Root, value);
                break;
            case 6:
                printf("Exiting...\n");
                break;
            default:
                printf("Invalid choice! Please try again.\n");
                break;
        }
    }

    return 0;
}
